let timer;
let timeLeft = 25 * 60;
let timerRunning = false;

function updateDisplay() {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    document.getElementById("counterValue").textContent =
        `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

function startTimer() {
    if (timerRunning) return;
    timerRunning = true;
    timer = setInterval(() => {
        if (timeLeft > 0) {
            timeLeft--;
            updateDisplay();
        } else {
            clearInterval(timer);
            timerRunning = false;
            document.getElementById("alarmSound").play();
            alert("Time's up!");
        }
    }, 1000);
}

function pauseTimer() {
    clearInterval(timer);
    timerRunning = false;
}

function stopTimer() {
    clearInterval(timer);
    timerRunning = false;
}

function resetTimer() {
    clearInterval(timer);
    timerRunning = false;
    timeLeft = 25 * 60;
    updateDisplay();
}

function setShortBreak() {
    clearInterval(timer);
    timerRunning = false;
    timeLeft = 5 * 60;
    updateDisplay();
}

function setLongBreak() {
    clearInterval(timer);
    timerRunning = false;
    timeLeft = 15 * 60;
    updateDisplay();
}

// Initialize display on page load
window.onload = updateDisplay;